package to_dos.builder.abstract_factory;

/* Create the AbstractFactoryTest class which uses the FactoryProducer 
 * to get AbstractFactory in order to get factories 
 * of concrete classes by passing an information such as type.
 */

public class AbstractFactoryTest {
	//TO-DO: Implement the main() method for testing purpose
	public static void main(String[] args) {
		// get shape factory
		ShapeFactory sf = new ShapeFactory(); 
		// get an object of Shape Rectangle
		Shape rectangle = sf.getShape("rectangle"); 
		// call draw method of Shape Rectangle
		rectangle.draw();
		// get an object of Shape Square
		Shape square = sf.getShape("square"); 
		// call draw method of Shape Square
		square.draw();
		// get shape factory
 
		// get an object of Shape Rectangle
 
		// call draw method of Shape Rectangle
 
		// get an object of Shape Square
 
		// call draw method of Shape Square
	}
}