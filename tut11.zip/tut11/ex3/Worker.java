package tut11.ex3;

public class Worker extends Human {
	
	private double hours; 
	private double salary;
	
	public Worker(String fName, String lName, double hours, double salary) {
		super(fName, lName);
		// TODO Auto-generated constructor stub
		this.hours = hours; 
		if(validateSalary(salary)) {
			this.salary = salary; 
		}else {
			throw new IllegalArgumentException("Expected value mismatch!Argument:\r\n" + 
					"weekSalary");
		}
	}
	
	public double getHours() {
		return hours;
	}
	
	public double getSalary() {
		return salary;
	} 
	
	public void setHours(double hours) {
		this.hours = hours;
	}
	
	public void setSalary(double salary) throws IllegalArgumentException {
		if(validateSalary(salary)) {
		this.salary = salary;
		}else {
			throw new IllegalArgumentException("Expected value mismatch!Argument:\r\n" + 
					"weekSalary"); 
		}
	}
	
	private boolean validateSalary(double salary) {
		return salary > 10.00; 
	}
	
}
