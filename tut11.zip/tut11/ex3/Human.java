package tut11.ex3;

public class Human {
	private String firstName; 
	private String lastName; 
	
	public Human(String fName, String lName) {
		// TODO Auto-generated constructor stub
		this.setFirstName(fName);
		this.setLastName(lName);; 
	}
	
	public String getFirstName() {
		return firstName;
	}
	
	public String getLastName() {
		return lastName;
	}
	public void setFirstName(String firstName) throws IllegalArgumentException {
		if(!validateFirstNameLetter(firstName)) {
			throw new IllegalArgumentException("Expected upper case letter!Argument:firstName"); 
		}
		if(!validateFirstNameLength(firstName)) {
			throw new IllegalArgumentException("Expected length at least 4 symbols!Argument: firstName"); 
		}
		if(validateFirstNameLength(firstName) && validateFirstNameLetter(firstName)) {
			this.firstName = firstName; 
		}
	}
	
	public void setLastName(String lastName) {
		if(!validateLastNameLetter(lastName)) {
			throw new IllegalArgumentException("Expected upper case letter!Argument:\r\n" + 
					"lastName"); 
		}
		if(!validateLastNameLength(lastName)) {
			throw new IllegalArgumentException("Expected length at least 3\r\n" + 
					"symbols!Argument: lastName"); 
		}
		if(validateLastNameLetter(lastName) && validateLastNameLength(lastName)) {
			this.lastName = lastName; 
		}
	}
	
	private boolean validateFirstNameLetter(String fName) {
		char firstLetter = fName.charAt(0); 
		return Character.isUpperCase(firstLetter) ; 		
	}
	private boolean validateFirstNameLength(String fName) {
		return fName.length() > 4; 
	}
	
	private boolean validateLastNameLetter(String lName) {
		char firstLetter = lName.charAt(0); 
		return Character.isUpperCase(firstLetter) ; 		
	}
	private boolean validateLastNameLength(String lName) {
		return lName.length() > 3; 
	}
	
}
