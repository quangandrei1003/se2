package tut11.ex3;

public class Student extends Human {
	private String facultyNumber; 
	public Student(String fName, String lName, String facultyNumber) {
		super(fName, lName);
		// TODO Auto-generated constructor stub
		if(validateFaculty(facultyNumber)) {
			this.facultyNumber = facultyNumber; 
		}else {
			throw new IllegalArgumentException("Invalid faculty number!"); 
		}
	}
	
	public String getFacultyNumber() {
		return facultyNumber;
	}
	public void setFacultyNumber(String facultyNumber) throws IllegalArgumentException {
		if(!validateFaculty(facultyNumber)) {
			throw new IllegalArgumentException("Invalid faculty number!"); 
		}else {
			this.facultyNumber = facultyNumber; 
		}
	}	
	private boolean validateFaculty(String faculty) {
		return faculty.length() > 5 && faculty.length() < 10; 
	}
}
