package tut11.ex1;

public class Child extends Person{

	public Child(String name, int age){
		super(name, age); 
	}
	
	protected boolean validateAge(int age){
		// TODO Auto-generated method stub
		return super.validateAge(age) && age < 15; 
	}
}
