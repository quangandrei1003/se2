package tut11.ex1;

public class Main {
	public static void main(String args[]) {
		Child c = new Child("anotherQuang", -5); 
		System.out.println(c.toString());
	}
}
