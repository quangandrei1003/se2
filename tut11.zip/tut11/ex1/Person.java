package tut11.ex1;

public class Person {

	protected String name; 
	protected int age; 
	
	public Person(String name, int age) throws IllegalArgumentException {
		if(validateAge(age)) {
			this.age = age; 
		}else {
			throw new IllegalArgumentException("Age is not valid!"); 
		}
		if(validateName(name)) {
			this.name = name; 
		}else {
			throw new IllegalArgumentException("Name is not valid");
		}
	}
	
	public void setAge(int age) throws IllegalArgumentException {
		if(!validateAge(age)) {
			throw new IllegalArgumentException("Age is not valid"); 
		}else {
			this.age = age; 
		}
	}
	public void setName(String name) throws IllegalArgumentException  {
		if(!validateName(name)) {
			throw new IllegalArgumentException("Name is not valid"); 
		}else {
			this.name = name; 
		}
	}
	public int getAge() {
		return age;
	}
	public String getName() {
		return name;
	}
	protected boolean validateAge(int age) {
		if(age > 1)
			return true; 
		else 
			return false; 
	}
	
	private boolean validateName(String name) {
		return name.length() > 3; 
	}
	@Override
	public String toString() {
		return "<Name :"+this.name+" Age: "+this.age+" >";  
	}
}
