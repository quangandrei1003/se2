package com.customermanagement.web;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.customermanagement.dao.*;
import com.customermanagement.model.Customer;
/**
 * Servlet implementation class CustomerServlet
 */
@WebServlet("/CustomerManagement")
public class CustomerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private CustomerDao customerDAO; 
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CustomerServlet() {
        this.customerDAO = new CustomerDao(); 
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		try {
			getAllCustomers(request, response);
		} catch (IOException | SQLException | ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	
	//get all customers
	private void getAllCustomers(HttpServletRequest request, HttpServletResponse response) throws IOException,SQLException, ServletException {
		List<Customer> listCustomers = customerDAO.selectAllCustomers(); 
		request.setAttribute("listCustomers", listCustomers);
		RequestDispatcher dispatcher = request.getRequestDispatcher("customer-list.jsp");
		dispatcher.forward(request, response);	
	}

}
