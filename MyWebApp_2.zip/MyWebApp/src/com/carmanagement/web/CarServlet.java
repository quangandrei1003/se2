package com.carmanagement.web;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.carmanagement.dao.*;
import com.carmanagement.model.*;

/**
 * Servlet implementation class CarServlet
 */
@WebServlet("/CarManagement")
public class CarServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private CarDao carDAO; 
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CarServlet() {
        this.carDAO = new CarDao();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		try {
			getAllCars(request, response);
		} catch (IOException | SQLException | ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	
	//get all cars
	private void getAllCars(HttpServletRequest request, HttpServletResponse response) throws IOException,SQLException, ServletException {
		List<Car> listCars = carDAO.selectAllCars();
		request.setAttribute("listCars", listCars);
		RequestDispatcher dispatcher = request.getRequestDispatcher("car-list.jsp");
		dispatcher.forward(request, response);
		
	}

}
