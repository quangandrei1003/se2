package com.carmanagement.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


import com.carmanagement.model.*;

public class CarDao {

	public CarDao() {
		// TODO Auto-generated constructor stub
	}

	private static String DB_URL = "jdbc:mysql://localhost:3306/se2?useSSL=false";
    private static String USER_NAME = "root";
    private static String PASSWORD = "1111";
	private static final String SELECT_ALL_CARS = "SELECT * FROM car";
	
	
	public static Connection getConnection(String dbURL, String userName,
            String password) {
        Connection conn = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection(dbURL, userName, password);
            System.out.println("Connect to MySQL database successfully!");
        } catch (Exception ex) {
            System.out.println("Connect to MySQL database failed!");
            
            ex.printStackTrace();
        }
        return conn;
    }
	
	public List<Car> selectAllCars() {

		List<Car> cars = new ArrayList<>();
		// Step 1: Establishing a Connection
		Connection connection = getConnection(DB_URL,USER_NAME,PASSWORD);
		try {
			// Step 2:Create a statement using connection object
		
			PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_CARS);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();
			// Step 4: Process the ResultSet object
			while (rs.next()) {
				int id = rs.getInt("id");
				String brand = rs.getString("brand");
				String name = rs.getString("name");
				int year = rs.getInt("year");
				cars.add(new Car(id, brand, name, year));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return cars;
	}
}
