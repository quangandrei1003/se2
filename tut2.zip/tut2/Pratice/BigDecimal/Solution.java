package BigDecimal;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;

 public class Solution {
	 
	 public static void main(String[] args) {
		 
		 String[] s = new String[] {}; 
		 Arrays.sort(s,Collections.reverseOrder(new Comparator<String>() { 

			@Override
			public int compare(String o1, String o2) {
				BigDecimal b1 = new BigDecimal(o1);
				BigDecimal b2 = new BigDecimal(02); 
				return b1.compareTo(b2); 
			}
		 }));
	 }
 }
